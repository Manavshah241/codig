function s(e){var t;const{keyCode:n,key:r}=e;return(r==="Enter"||n===13||n===10)&&((t=e.nativeEvent)==null?void 0:t.isComposing)!==!0}export{s as i};
